<footer class="footer">
    <div class="container-fluid">
        <nav class="pull-left">
            <div class="col-xs-12" style="margin-top: -1em; margin-bottom: -0.1em">
                <center>
                    <a href="https://www.pengenngoding.com">
                        <img height="15px" src="<?php echo base_url('assets/img/official.png') ?>" alt="">
                    </a>
                </center>
            </div>
            <ul class="nav">
                <li class="nav-item">
                    <!-- <a class="nav-link" href="https://www.pengenngoding.com">
                        <img height="15px" src="<?php echo base_url('assets/img/official.png') ?>" alt="">
                    </a> -->
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">
                        <img height="30px" src="<?php echo base_url('assets/img/pengen.PNG') ?>" alt="">
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">
                        <img height="30px" src="<?php echo base_url('assets/img/logo_bawah_2.png') ?>" alt="">
                    </a>
                </li>
            </ul>
        </nav>
        <div class="copyright ml-auto">
            SIPP v1 -<a href="http://jepara.pramukajateng.or.id"> Kwartir Cabang Jepara</a> - 2021
        </div>              
    </div>
</footer>